// EXPRESS  
// API REST
const express = require("express");
const cors = require("cors");
const Usuario = require("./configuracao");
const app = express();
app.use(express.json());
app.use(cors());

//LISTAR DADOS FIREBASE
//LISTAR DADOS FIREBASE
//LISTAR DADOS FIREBASE
app.get("/", async (req, res) => {
  const snapshot = await Usuario.get();
  const list = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  res.send(list);
});

//CRIAR USUARIOS
//CRIAR USUARIOS
//CRIAR USUARIOS

app.post("/criar", async (req, res) => {
  const data = req.body;
  await Usuario.add({ data });
  res.send({ msg: "Usuario adcionado ao sistema" });
});

//ATUALIZAR USUARIOS
//ATUALIZAR USUARIOS

app.post("/atualizar", async (req, res) => {
  const id = req.body.id;
  delete req.body.id;
  const data = req.body;
  await Usuario.doc(id).update(data);
  res.send({ msg: "Usuarios atualizado" });
});

//DELETAR USUARIOS

app.post("/deletar", async (req, res) => {
  const id = req.body.id;
  await Usuario.doc(id).delete();
  res.send({ msg: "Usuário deletado" });
});
app.listen(5001, () => console.log("Rodando na porta 5001"));


//CRUD FIREBASE E NODEJS PORTA 5001