const firebase = require("firebase");
const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
  measurementId: "",
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
//Firebase Conexão  NODEJS // 
const Usuario = db.collection("Usuarios");
module.exports = Usuario;
